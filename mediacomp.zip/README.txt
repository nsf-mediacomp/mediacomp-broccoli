hi gray-chan
